/* ============================================================
   app.js — presentation engine
   ------------------------------------------------------------
   • Only ONE slide lives in the DOM at a time (plus the one
     animating out). 100 or 1,000 slides cost the same.
   • Images load lazily: a 24px blur placeholder is inline, the
     real WebP streams in, and the NEXT slide's image is
     pre-fetched while the user reads.
   • State (journey + in-slide choices) lives in the URL hash,
     so links are shareable and Back/Forward work.
   ============================================================ */
(() => {
  "use strict";
  const $ = (s, el = document) => el.querySelector(s);
  const h = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const IMG = "img/";
  const LQIP = window.LQIP || {};
  // src(): resolves an image name to a URL. If a build inlined images (window.IMGDATA), use those.
  const src = (n, mobile) => (window.IMGDATA && window.IMGDATA[n]) || `${IMG}${n}${mobile ? "-m" : ""}.webp`;
  const stage = $("#stage"), sectionsEl = $("#sections");

  /* ---------------- state & routing ---------------- */
  const state = { id: null, market: null, choices: {} };   // choices: ptype, profile, etc.
  const DEFAULT_MARKET = "dubai";
  const marketOf = () => state.market || DEFAULT_MARKET;

  function path() { return DECK.slides.filter(s => !s.market || s.market === marketOf()); }
  function indexOf(id) { return path().findIndex(s => s.id === id); }
  const byId = id => DECK.slides.find(s => s.id === id);

  function readHash() {
    const m = location.hash.match(/^#\/?([^?]*)\??(.*)$/);
    const id = m && m[1] ? decodeURIComponent(m[1]) : DECK.slides[0].id;
    const q = new URLSearchParams(m ? m[2] : "");
    if (q.get("m") && DECK.markets[q.get("m")]) state.market = q.get("m");
    q.forEach((v, k) => { if (k !== "m") state.choices[k] = v; });
    return byId(id) ? id : DECK.slides[0].id;
  }
  function writeHash(replace) {
    const q = new URLSearchParams();
    if (state.market) q.set("m", state.market);
    Object.entries(state.choices).forEach(([k, v]) => q.set(k, v));
    const hash = "#/" + state.id + (q.toString() ? "?" + q : "");
    if (hash === location.hash) return;
    history[replace ? "replaceState" : "pushState"](null, "", hash);
  }

  /* ---------------- images ---------------- */
  function bgHTML(name, cls = "") {
    if (!name) return "";
    const lq = LQIP[name] ? ` style="background-image:url(${LQIP[name]})"` : "";
    return `<div class="bg ${cls}"${lq}><img alt="" decoding="async" fetchpriority="high"
      src="${src(name, true)}" srcset="${src(name, true)} 960w, ${src(name)} 1920w" sizes="100vw"
      onload="this.classList.add('ready')"></div>`;
  }
  const photoURL = name => name ? `url(${src(name, window.innerWidth <= 1100)})` : "";
  function preload(slide) {
    if (!slide) return;
    [slide.bg, slide.bg2, ...(slide.photos || []), ...((slide.cities || []).map(c => c.photo))].filter(Boolean)
      .forEach(n => { const i = new Image(); i.src = src(n, window.innerWidth <= 1100); });
  }

  /* ---------------- shared pieces ---------------- */
  const icon = dir => dir === "down"
    ? `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M4 8c3 3 6 6 9 5s4-4 7 1"/><path d="M20 10v4h-4"/></svg>`
    : dir === "flat" ? `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M3 12h18"/></svg>`
    : `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M4 16c3-3 6-6 9-5s4 4 7-1"/><path d="M20 14v-4h-4"/></svg>`;

  const title = (s, cls = "t-1") => `<h1 class="${cls}">${s.num ? `<span class="num">${h(s.num)}</span>` : ""}${h(s.title)}</h1>`;
  const cityLine = s => s.city ? `<div class="city">${h(s.city)}</div>` : "";
  const stat = x => `<div class="stat">
      <div class="v">${x.pre ? `<span class="pre">${h(x.pre)}</span>` : ""}${h(x.v)}</div>
      ${x.unit ? `<div class="u">${h(x.unit)}</div>` : ""}
      ${x.l ? `<div class="l">${h(x.l)}</div>` : ""}${x.t ? `<div class="t">${h(x.t)}</div>` : ""}</div>`;
  const sparkline = (trend, hi) => {
    const pts = trend < 0 ? "0,38 25,40 45,52 70,58 100,64 130,66 150,60" : trend > 0 ? "0,62 25,60 45,58 70,55 100,36 130,32 150,34" : "0,50 25,50 45,49 70,51 100,50 130,50 150,50";
    const last = pts.split(" ").pop().split(",");
    const col = trend < 0 ? "#E89A9C" : "#7BA0B2";
    return `<svg viewBox="0 0 150 90" preserveAspectRatio="none" aria-hidden="true">
      <line x1="0" x2="150" y1="20" y2="20" stroke="currentColor" stroke-opacity=".25" stroke-dasharray="2 3"/>
      <line x1="0" x2="150" y1="50" y2="50" stroke="currentColor" stroke-opacity=".4"/>
      <line x1="0" x2="150" y1="80" y2="80" stroke="currentColor" stroke-opacity=".25" stroke-dasharray="2 3"/>
      <polygon points="0,90 ${pts} 150,90" fill="${col}" fill-opacity=".25"/>
      <polyline points="${pts}" fill="none" stroke="${col}" stroke-width="1.5"/>
      <rect x="${+last[0] - 25}" y="${+last[1] - 4}" width="8" height="8" transform="rotate(45 ${+last[0] - 21} ${+last[1]})" fill="${trend < 0 ? "#E89A9C" : "#2C537A"}"/></svg>`;
  };
  const chooserHTML = (c, cur) => `<div class="chooser" data-key="${h(c.key)}"><span class="label">${h(c.label)}</span>
      ${c.options.map(([k, l]) => `<button type="button" data-val="${h(k)}" aria-pressed="${cur === k}">${h(l)}</button>`).join("")}</div>`;

  /* ---------------- templates ---------------- */
  const TPL = {
    cover: s => `${bgHTML(s.bg)}<div class="wash bottom"></div><div class="inner">
      <h1>${h(s.title)}</h1><p>${h(s.sub)}</p>
      <button class="start" data-go="next">Start the handbook</button>
      <div class="brand">betterhomes</div></div>`,

    toc: s => `<div class="inner"><h1>${h(s.title)}</h1>${s.groups.map(g => `<div class="group">
        <h3>${h(g.title)}</h3><span class="pg">${h(g.page)}</span>
        <ul>${g.items.map(i => `<li><button type="button" data-jump="${h(i.slice(0, 3))}">${h(i)}</button></li>`).join("")}</ul></div>`).join("")}</div>`,

    opener: s => `${bgHTML(s.bg)}<div class="wash light"></div><div class="wash bottom"></div><div class="inner">
      <div class="head"><div>
        <div class="num">${h(s.num)}</div><h1 class="t-hero">${h(s.title)}</h1>
        ${s.sub ? `<h2 class="t-2" style="margin-top:1.2rem">${h(s.sub)}</h2>` : ""}
        ${s.kicker ? `<div class="kicker">${h(s.kicker)}</div>` : ""}
        ${s.lede ? `<p class="lede">${h(s.lede)}</p>` : ""}<p class="body">${h(s.body)}</p>
        ${s.chooser ? chooserHTML(s.chooser, state.choices[s.chooser.key] || s.chooser.options[0][0]) : ""}
      </div>${s.author ? `<div>
        <div class="author"><div class="ph" style="background-image:${photoURL(s.author.photo)}"></div><div><b>${h(s.author.name)}</b><span class="small">${h(s.author.role)}</span></div></div>
        <div class="quote"><h3>${h(s.author.quoteTitle)}</h3><p class="body">${h(s.author.quote)}</p></div></div>` : "<div></div>"}</div>
      ${s.stats ? `<h2 class="stats-title">${h(s.statsTitle)}</h2><div class="stats">${s.stats.map(stat).join("")}</div>` : ""}</div>`,

    learn: s => `${bgHTML(s.bg)}<div class="wash light"></div><div class="inner">${title(s)}<p class="body">${h(s.lede)}</p>
      <div class="grid">${s.cols.map(c => `<div class="col"><h3><span class="n">${h(c.n)}</span>${h(c.h)}</h3>
        ${c.items.map(([b, t]) => `<div class="item"><b>${h(b)}</b><p>${h(t)}</p></div>`).join("")}</div>`).join("")}</div></div>`,

    hub: s => `${bgHTML(s.bg, s.bg2 ? "first" : "")}${s.bg2 ? bgHTML(s.bg2, "second") : ""}<div class="wash light"></div>
      ${s.bg2 ? `<span class="label" style="left:32%;top:62%">Abu Dhabi</span><span class="label" style="left:76%;top:56%">Dubai</span>` : ""}
      <div class="inner">${title(s)}${s.lede ? `<p class="lede">${h(s.lede)}</p>` : ""}<p class="body">${h(s.body ?? "")}</p>
      ${s.cols ? `<div class="summary">${s.cols.map(c => `<p>${h(c)}</p>`).join("")}</div>` : ""}
      ${s.nochoice ? "" : `<h2 class="prompt">${h(s.prompt)}</h2><div class="chips"><div class="group" role="group">
        ${Object.entries(DECK.markets).map(([k, m]) => `<button type="button" data-market="${k}" aria-pressed="${state.market === k}">${h(m.label)}</button>`).join("")}
        </div><button class="go ${state.market ? "on" : ""}" data-go="next" aria-label="Continue">
        <svg width="22" height="14" viewBox="0 0 22 14" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M14 1l6 6-6 6M20 7H0"/></svg></button></div>`}
      ${s.aside ? `<div class="aside"><h3>${h(s.aside.h)}</h3><p class="small" style="margin:.4rem 0 .6rem">${h(s.aside.t)}</p><ul>${s.aside.items.map(i => `<li>${h(i)}</li>`).join("")}</ul></div>` : ""}</div>`,

    signals: s => `${bgHTML(s.bg)}<div class="wash dark"></div><div class="inner ${s.pending ? "pending" : ""}">${cityLine(s)}${title(s)}<p class="lede">${h(s.lede)}</p>
      <h2 class="group-t">${h(s.group)}</h2><div class="grid">${s.signals.map(x => `<div class="sig"><div class="ic">${icon(x.dir)}</div><div>
        <div class="v ${x.v.length > 6 ? "sm" : ""}">${h(x.v)}</div><div class="l">${h(x.l)}</div><div class="t">${h(x.t)}</div></div></div>`).join("")}</div>
      <div class="note"><h3>${h(s.note.h)}</h3><p class="body">${h(s.note.t)}</p></div></div>`,

    chartcards: s => `${bgHTML(s.bg)}${s.bg ? `<div class="wash dark"></div>` : ""}<div class="inner">${cityLine(s)}${title(s)}<hr class="rule">
      <div class="axis"><div class="yl">${(s.axis || ["", "", ""]).map(a => `<span>${h(a)}</span>`).join("")}</div>
      ${s.cards.map(c => `<div class="card ${c.hi ? "hi" : ""}">${sparkline(c.trend, c.hi)}<div class="v">${h(c.v)}</div><div class="l">${h(c.l)}</div><div class="t">${h(c.t)}</div></div>`).join("")}</div>
      <div class="notes">${s.notes.map(n => `<div>${n.h ? `<h3>${h(n.h)}</h3>` : ""}<p>${h(n.t)}</p></div>`).join("")}</div></div>`,

    statgrid: s => `<div class="inner ${s.pending ? "pending" : ""}">${cityLine(s)}${title(s)}<hr class="rule">
      <div class="grid">${s.stats.map(x => `<div class="tile ${x.photo ? "photo" : ""}">${x.photo ? `<div class="ph" style="background-image:${photoURL(x.photo)}"></div>` : ""}
        <div class="v">${h(x.v)}</div><div class="l">${h(x.l)}</div><div class="t">${h(x.t)}</div></div>`).join("")}</div>
      <div class="rows">${s.rows.map(r => `<div class="row"><h3>${h(r.h)}</h3>${r.cols ? `<div class="cols-2">${r.cols.map(c => `<p>${h(c)}</p>`).join("")}</div>` : `<p>${h(r.t)}</p>`}</div>`).join("")}</div></div>`,

    survey: s => `<div class="inner">${cityLine(s)}${title(s)}<hr class="rule">
      <div class="grid">${s.stats.map(x => `<div class="tile ${x.photo ? "photo" : ""}">${x.photo ? `<div class="ph" style="background-image:${photoURL(x.photo)}"></div>` : ""}
        <div class="v">${h(x.v)}</div><div class="l">${h(x.l)}</div><div class="t">${h(x.t)}</div></div>`).join("")}</div></div>`,

    compare: s => {
      const ph = s.photos || [];
      const head = s.head.map((c, i) => i === 0 ? `<th>${h(c)}</th>` : ph[i - 1]
        ? `<th class="ph" style="background-image:${photoURL(ph[i - 1])}"><span>${h(c)}${s.subhead ? `<small>${h(s.subhead[i - 1])}</small>` : ""}</span></th>` : `<th>${h(c)}</th>`).join("");
      return `<div class="inner">${title(s)}${s.intro ? `<p class="lede">${h(s.intro)}</p>` : ""}<div class="wrap"><table><thead><tr>${head}</tr></thead><tbody>
        ${s.rows.map(r => `<tr>${r.map((c, i) => `<td class="${i ? "col" : ""}">${h(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>
        ${s.after ? `<div class="after">${s.after.h ? `<h3>${h(s.after.h)}</h3>` : ""}${s.after.sub ? `<div class="sub">${h(s.after.sub)}</div>` : ""}
          <div class="cols">${s.after.cols.map(c => `<p>${h(c)}</p>`).join("")}</div>${s.after.foot ? `<p class="foot">${h(s.after.foot)}</p>` : ""}</div>` : ""}</div>`;
    },

    fivecols: s => `${bgHTML(s.bg)}<div class="wash dark"></div><div class="inner">${cityLine(s)}${title(s)}
      ${s.source ? `<div class="src">${h(s.source)}</div>` : ""}${s.intro ? `<p class="intro">${h(s.intro)}</p>` : ""}
      <div class="grid">${s.cols.map((c, i) => `<div class="col ${i === s.cols.length - 1 && s.cols[i].hl && !s.trade ? "last" : ""}"><div class="q">${h(c.q)}</div>
        ${c.v ? `<div class="v">${c.pre ? `<span class="pre">${h(c.pre)}</span>` : ""}${h(c.v)}</div>` : ""}${c.l ? `<div class="l">${h(c.l)}</div>` : ""}
        ${c.hl ? `<div class="hl">${h(c.hl)}</div>` : ""}${c.t ? `<div class="t">${h(c.t)}</div>` : ""}</div>`).join("")}</div>
      ${s.trade ? `<div class="trade"><h3>${h(s.trade.h)}</h3><p>${h(s.trade.t)}</p></div>` : ""}</div>`,

    tabs: s => {
      const cur = +(state.choices["tab-" + s.id] || 0), t = s.tabs[cur];
      return `${bgHTML(s.bg)}<div class="wash dark"></div><div class="inner">
        <div class="tabs" role="tablist">${s.tabs.map((x, i) => `<button class="tab" role="tab" data-tab="${i}" aria-selected="${i === cur}"><span class="n">${h(x.n)}</span><span class="h">${h(x.h)}</span></button>`).join("")}</div>
        <div class="panel" role="tabpanel"><div class="stats">${t.stats.map(x => `<div><div class="v">${h(x.v)}</div><div class="l">${h(x.l)}</div></div>`).join("")}</div>
        <h3>${h(t.h2)}</h3><div class="cols">${t.cols.map(c => `<p>${h(c)}</p>`).join("")}</div>${t.foot ? `<div class="ft">${h(t.foot)}</div>` : ""}</div></div>`;
    },

    cities: s => `<div class="inner">${cityLine(s)}${title(s)}<div class="grid">${s.cities.map(c => `<div class="cc" style="background-image:${photoURL(c.photo)}">
        <h3>${h(c.name)}</h3><div class="tag">${h(c.tag)}</div><p>${h(c.t)}</p></div>`).join("")}</div></div>`,

    global: s => `${bgHTML(s.bg)}<div class="wash dark"></div><div class="inner">${title(s)}<div class="grid">${s.cities.map(c => `<div class="gc"><h3>${h(c.name)}</h3><dl>
        <dt>Representative one-bedroom price</dt><dd>${h(c.price)}</dd><dt>Indicative gross rental yield</dt><dd>${h(c.yield)}</dd><dt>Estimated net rental yield</dt><dd>${h(c.net)}</dd></dl><p>${h(c.t)}</p></div>`).join("")}</div></div>`,

    checklist: s => {
      const key = s.chooser ? s.chooser.key : "ptype";
      const variant = state.choices[key] || (s.chooser ? s.chooser.options[0][0] : "ready");
      const steps = s.steps || s.variants[variant] || s.variants[Object.keys(s.variants)[0]];
      const page = +(state.choices["pg-" + s.id] || 0), per = 3, pages = Math.ceil(steps.length / per);
      const shown = steps.slice(page * per, page * per + per);
      const chooser = s.chooser || (s.variants ? { label: "Property type", key: "ptype", options: [["offplan", "Off-plan"], ["ready", "Ready"]] } : null);
      const focusStep = shown.find(x => x.focus);
      return `${bgHTML(s.bg)}<div class="wash dark"></div><div class="inner"><div class="toolbar"><div>${title(s)}
        ${s.lede ? `<p class="lede">${h(s.lede)}</p>` : ""}${s.body ? `<p class="body">${h(s.body)}</p>` : ""}</div>
        ${chooser ? chooserHTML(chooser, variant) : ""}</div>
        <div class="steps">${shown.map(x => `<div class="step"><div class="n">${h(x.n)}</div><h3>${h(x.h)}</h3><p class="t">${h(x.t)}</p>
          <div class="rv">Review:</div><ul>${x.items.map(i => `<li>${h(i)}</li>`).join("")}</ul>
          ${x.sub ? `<div class="sub">${h(x.sub)}</div>` : ""}${x.q ? `<div class="q">${h(x.q)}</div>` : ""}</div>`).join("")}</div>
        ${pages > 1 ? `<div class="pager">${Array.from({ length: pages }, (_, i) => `<button type="button" data-page="${i}" aria-pressed="${i === page}">${String(i * per + 1).padStart(2, "0")}–${String(Math.min(steps.length, i * per + per)).padStart(2, "0")}</button>`).join("")}</div>` : ""}
        ${focusStep ? `<div class="focus"><b>For your profile, focus on:</b><ul>${focusStep.focus.map(f => `<li>${h(f)}</li>`).join("")}</ul></div>` : ""}</div>`;
    },

    map: s => {
      const mk = marketOf() === "abudhabi" ? "abudhabi" : "dubai";
      const pins = s.pins[mk], cur = state.choices["pin-" + s.id] || pins[0][0];
      const c = s.card;
      return `${bgHTML((s.bgs && s.bgs[mk]) || s.bg)}<div class="wash dark"></div><div class="inner"><div class="toolbar" style="justify-content:space-between;align-items:flex-start">
        <div>${title(s)}<h2 class="t-2" style="margin-top:.8rem">${h(s.sub)} in ${h(s.marketLabels[mk])}</h2></div>
        <div style="display:flex;gap:.5rem;flex-wrap:wrap">${["dubai", "abudhabi"].map(k => `<button type="button" data-market="${k}" data-stay="1" aria-pressed="${mk === k}">${h(DECK.markets[k].label)}</button>`).join("")}
          ${s.filters.map((f, i) => `<button type="button" aria-pressed="${i === 0}">${h(f)}</button>`).join("")}</div></div>
        <div class="mapwrap">${pins.map(([n, x, y]) => `<button class="pin" style="left:${x * 100}%;top:${y * 100}%" data-pin="${h(n)}" aria-pressed="${n === cur}">${h(n)}</button>`).join("")}</div>
        <div class="ccard"><div class="name">${h(cur)}<small>${h(c.status)} · ${h(c.type)}</small></div>
          <div class="metrics"><div><div class="v">${h(c.price)}</div><div class="l">${h(c.priceLabel)}</div></div><div><div class="v">${h(c.yield)}</div><div class="l">${h(c.yieldLabel)}</div></div><div><div class="v">${h(c.entry)}</div><div class="l">${h(c.entryLabel)}</div></div><div><div class="v">${h(c.range)}</div><div class="l">${h(c.rangeLabel)}</div></div></div>
          <div class="notes">${c.notes.map(([b, t]) => `<div><b>${h(b)}</b>${h(t)}</div>`).join("")}</div></div></div>`;
    },

    communities: s => {
      const mk = marketOf() === "abudhabi" ? "abudhabi" : "dubai";
      const list = s.lists[mk], cur = state.choices["pin-" + s.id] || list[0];
      const c = byId("s5-open").card;
      return `<div class="inner"><div class="toolbar" style="display:flex;justify-content:space-between;align-items:flex-start">
        ${title(s.title ? { ...s, title: `${DECK.markets[mk].label} communities` } : s)}
        <div style="display:flex;gap:.5rem">${["dubai", "abudhabi"].map(k => `<button type="button" class="chip" data-market="${k}" data-stay="1" aria-pressed="${mk === k}" style="padding:.5rem .9rem;border:1px solid rgba(255,255,255,.3);font-size:.74rem;${mk === k ? "background:#fff;color:#1F343F" : ""}">${h(DECK.markets[k].label)}</button>`).join("")}</div></div>
        <div class="chips-list">${list.map(n => `<button type="button" data-pin="${h(n)}" aria-pressed="${n === cur}">${h(n)}</button>`).join("")}</div>
        <div class="ccard" style="margin-top:2rem"><div class="name">${h(cur)}<small>${h(c.status)} · ${h(c.type)}</small></div>
          <div class="metrics"><div><div class="v">${h(c.price)}</div><div class="l">${h(c.priceLabel)}</div></div><div><div class="v">${h(c.yield)}</div><div class="l">${h(c.yieldLabel)}</div></div><div><div class="v">${h(c.entry)}</div><div class="l">${h(c.entryLabel)}</div></div><div><div class="v">${h(c.range)}</div><div class="l">${h(c.rangeLabel)}</div></div></div>
          <div class="notes">${c.notes.map(([b, t]) => `<div><b>${h(b)}</b>${h(t)}</div>`).join("")}</div></div>
        <p class="foot">Community figures shown are placeholders pending the final data set.</p></div>`;
    },

    split: s => `<div class="title"><div class="num">${h(s.num)}</div><h1 class="t-hero">${h(s.title)}</h1></div><div class="inner"><div class="halves">
      ${[s.left, s.right].map(x => `<button class="half" style="background-image:${photoURL(x.photo)}" data-choice="${h(s.chooserKey)}:${h(x.key)}" data-go="next"><div><div class="d"></div><h3>${h(x.h)}</h3><p>${h(x.t)}</p></div></button>`).join("")}</div></div>`,

    process: s => {
      const cur = +(state.choices["step-" + s.id] || 0), st = s.steps[cur];
      return `${bgHTML(s.bg)}<div class="wash dark"></div><div class="inner">${title(s)}<p class="body">${h(s.body)}</p>
        <div class="timeline" role="tablist">${s.steps.map((x, i) => `<button class="tl" role="tab" data-tab="${i}" aria-selected="${i === cur}"><span class="n">${h(x.n)}</span><span class="h">${h(x.h)}</span><span class="tm">${h(x.time)}</span></button>`).join("")}</div>
        <div class="detail"><span class="n">${h(st.n)}</span><h3>${h(st.h)}</h3><div class="tm">Typical planning time · ${h(st.time)}</div><p class="t">${h(st.t)}</p>
          <div class="cols">${st.cols.map(c => `<div><b>${h(c.h)}</b><ul>${c.items.map(i => `<li>${h(i)}</li>`).join("")}</ul></div>`).join("")}</div>
          <div class="end">${h(st.end)}</div></div></div>`;
    }
  };
  const DARK = new Set(["cover", "signals", "fivecols", "tabs", "global", "checklist", "map", "communities", "split", "process"]);

  /* ---------------- render ---------------- */
  let busy = false;
  function render(id, dir = 1, replace = false) {
    const slide = byId(id); if (!slide) return;
    state.id = id;
    const prev = $(".slide", stage);
    const el = document.createElement("section");
    const dark = DARK.has(slide.tpl) || slide.dark;
    el.className = `slide tpl-${slide.tpl} ${dark ? "dark" : ""} ${dir < 0 ? "back" : ""} enter`;
    el.innerHTML = TPL[slide.tpl](slide);
    if (prev) { prev.classList.toggle("back", dir < 0); prev.classList.add("exit"); prev.addEventListener("animationend", () => prev.remove(), { once: true }); setTimeout(() => prev.remove(), 600); }
    stage.appendChild(el);
    stage.classList.toggle("on-dark", dark);
    writeHash(replace);
    updateChrome(slide);
    const p = path(), i = p.findIndex(s => s.id === id);
    preload(p[i + 1]); preload(p[i - 1]);
    document.title = (slide.title || DECK.meta.title) + " · betterhomes";
  }
  function rerender() { const el = $(".slide", stage); if (!el) return; const s = byId(state.id); el.innerHTML = TPL[s.tpl](s); writeHash(true); updateChrome(s); }

  function updateChrome(slide) {
    const p = path(), i = p.findIndex(s => s.id === slide.id), n = p.length;
    const pct = Math.round(i / (n - 1) * 100);
    $("#pfill").style.width = pct + "%"; $("#pdot").style.left = pct + "%"; $("#ppct").style.left = pct + "%"; $("#ppct").textContent = pct + "%";
    $("#counter").textContent = `Page ${String(i + 1).padStart(2, "0")} / ${n}`;
    $("#jlabel").textContent = state.market ? DECK.markets[state.market].label + " journey" : "";
    $("#back").disabled = i === 0; $("#next").disabled = i === n - 1;
    sectionsEl.querySelectorAll("li").forEach(li => li.classList.toggle("active", li.dataset.sec === slide.section));
  }

  function go(delta) {
    const p = path(), i = indexOf(state.id);
    let j = i + delta;
    if (i === -1) j = 0;                     // current slide dropped out of the journey — restart from nearest
    if (j < 0 || j >= p.length) return;
    render(p[j].id, delta);
  }
  function jumpToSection(sec) { const s = path().find(x => x.section === sec); if (s) render(s.id, 1); }

  /* ---------------- chrome: sidebar + menu ---------------- */
  sectionsEl.innerHTML = DECK.sections.map(s => `<li data-sec="${s.id}"><button type="button">${h(s.title)}</button></li>`).join("");
  sectionsEl.addEventListener("click", e => { const li = e.target.closest("li"); if (li) jumpToSection(li.dataset.sec); });

  const menu = $("#menu");
  function openMenu(open) {
    menu.classList.toggle("open", open); $("#burger").setAttribute("aria-expanded", open);
    if (!open) return;
    $("#menumarkets").innerHTML = Object.entries(DECK.markets).map(([k, m]) => `<button type="button" data-market="${k}" data-stay="1" aria-pressed="${state.market === k}">${h(m.label)}</button>`).join("");
    $("#menulist").innerHTML = DECK.sections.map(sec => { const items = path().filter(s => s.section === sec.id); return items.length ? `<div class="sec"><h3>${h(sec.num)} ${h(sec.title)}</h3>${items.map(s => `<button type="button" data-jump-id="${s.id}" class="${s.id === state.id ? "cur" : ""}">${h(s.num ? s.num + " " : "")}${h(s.title)}${s.city ? ` — ${h(s.city)}` : ""}</button>`).join("")}</div>` : ""; }).join("");
  }
  $("#burger").addEventListener("click", () => openMenu(!menu.classList.contains("open")));
  $("#menuclose").addEventListener("click", () => openMenu(false));
  menu.addEventListener("click", e => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.market) { state.market = b.dataset.market; openMenu(true); rerender(); }
    if (b.dataset.jumpId) { openMenu(false); render(b.dataset.jumpId, 1); }
  });

  /* ---------------- in-slide interactions (event delegation) ---------------- */
  stage.addEventListener("click", e => {
    const b = e.target.closest("button"); if (!b) return;
    const s = byId(state.id);
    if (b.dataset.market) { state.market = b.dataset.market; if (b.dataset.stay) rerender(); else { b.closest(".group").querySelectorAll("button").forEach(x => x.setAttribute("aria-pressed", x === b)); $(".go", stage)?.classList.add("on"); writeHash(true); updateChrome(s); } return; }
    if (b.dataset.choice) { const [k, v] = b.dataset.choice.split(":"); state.choices[k] = v; }
    if (b.closest(".chooser")) { state.choices[b.closest(".chooser").dataset.key] = b.dataset.val; delete state.choices["pg-" + s.id]; rerender(); return; }
    if (b.dataset.tab !== undefined) { state.choices[(s.tpl === "process" ? "step-" : "tab-") + s.id] = b.dataset.tab; rerender(); return; }
    if (b.dataset.page !== undefined) { state.choices["pg-" + s.id] = b.dataset.page; rerender(); return; }
    if (b.dataset.pin) { state.choices["pin-" + s.id] = b.dataset.pin; rerender(); return; }
    if (b.dataset.jump) { const t = DECK.slides.find(x => x.num === b.dataset.jump); if (t) render(t.id, 1); return; }
    if (b.dataset.go === "next") go(1);
  });

  $("#back").addEventListener("click", () => go(-1));
  $("#next").addEventListener("click", () => go(1));
  document.addEventListener("keydown", e => {
    if (e.target.matches("input,textarea")) return;
    if (e.key === "ArrowRight" || e.key === "PageDown" || e.key === " ") { e.preventDefault(); go(1); }
    else if (e.key === "ArrowLeft" || e.key === "PageUp") { e.preventDefault(); go(-1); }
    else if (e.key === "Escape") openMenu(false);
    else if (e.key.toLowerCase() === "m") openMenu(!menu.classList.contains("open"));
  });
  // swipe
  let tx = 0, ty = 0;
  stage.addEventListener("touchstart", e => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
  stage.addEventListener("touchend", e => { const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty; if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) go(dx < 0 ? 1 : -1); }, { passive: true });

  window.addEventListener("popstate", () => { const id = readHash(); const dir = indexOf(id) < indexOf(state.id) ? -1 : 1; render(id, dir, true); });

  /* ---------------- boot ---------------- */
  render(readHash(), 1, true);
})();
