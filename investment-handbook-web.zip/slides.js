/* ============================================================
   slides.js — content for the UAE property investment handbook
   ------------------------------------------------------------
   HOW IT WORKS
   • DECK.sections   → the left-hand rail and menu
   • DECK.slides     → an ordered list. Each slide has:
       id       unique, used in the URL  (#/slide-id)
       section  which section it belongs to
       tpl      which template renders it (see templates in app.js)
       market   OPTIONAL — "dubai" | "abudhabi" | "compare"
                A slide with a market only appears in that journey.
                Slides without a market appear in every journey.
       bg       OPTIONAL — image name from /img (without extension)
       ...      template-specific fields

   JOURNEYS
   A "hub" slide offers choices. Choosing one sets the current
   market, which filters the slide list. Switch the market at any
   time from the menu — the deck re-routes instantly.

   To add a slide: append an object here. No other changes needed.
   ============================================================ */

window.DECK = {
  meta: { title: "UAE property investment handbook", year: "2026", brand: "betterhomes" },

  markets: {
    dubai:    { label: "Dubai" },
    abudhabi: { label: "Abu Dhabi" },
    compare:  { label: "Compare both" }
  },

  sections: [
    { id: "s1", num: "01", title: "Why the UAE remains on the investor radar" },
    { id: "s2", num: "02", title: "Why the UAE keeps attracting global property investors" },
    { id: "s3", num: "03", title: "What to check before you buy" },
    { id: "s4", num: "04", title: "Which investment scenario fits your goals?" },
    { id: "s5", num: "05", title: "The communities worth considering" },
    { id: "s6", num: "06", title: "What happens after you choose a property" },
    { id: "s7", num: "07", title: "The support you may need along the way" },
    { id: "s8", num: "08", title: "What changes when you invest from the UK" },
    { id: "s9", num: "09", title: "Your next move" }
  ],

  slides: [

    /* ───────────────────────── COVER & CONTENTS ───────────────────────── */
    { id: "cover", tpl: "cover", bg: "cover",
      title: "UAE property investment handbook", sub: "Your personalised guide" },

    { id: "contents", tpl: "toc", title: "Table of content",
      groups: [
        { title: "Why the UAE remains on the investor radar", page: "01", items: [
          "1.1 What you'll learn in this handbook",
          "1.2 How Dubai and Abu Dhabi markets responded to uncertainty",
          "1.3 Where Dubai and Abu Dhabi's property markets stand today",
          "1.4 How residents see the market ahead" ] },
        { title: "Why the UAE keeps attracting global property investors", page: "02", items: [
          "2.1 The demand drivers behind the UAE property market",
          "2.2 How the UAE compares within the GCC",
          "2.3 How the UAE compares with global property cities" ] },
        { title: "What to check before you buy", page: "03", items: [
          "3.1 Verify your property", "3.2 Know the full cost before you buy",
          "3.3 Check whether the property fits your investment goal" ] },
        { title: "Which investment scenario fits your goals?", page: "04", items: [ "4.1 Five investor routes compared" ] },
        { title: "The communities worth considering", page: "05", items: [ "5.1 Dubai and Abu Dhabi communities" ] },
        { title: "What happens after you choose a property", page: "06", items: [ "6.1 Buying a ready property in Dubai" ] },
        { title: "The support you may need along the way", page: "07", items: [ "7.1 Before, during and after your purchase" ] },
        { title: "What changes when you invest from the UK", page: "08", items: [ "8.1 Financial, tax and practical considerations" ] },
        { title: "Your next move", page: "09", items: [ "9.1 Turn what you have learned into a next step" ] }
      ] },

    /* ───────────────────────── 01  INVESTOR RADAR ───────────────────────── */
    { id: "s1-open", section: "s1", tpl: "opener", bg: "villa-pool", num: "01",
      title: "Why the UAE remains on the investor radar",
      kicker: "UAE property:",
      lede: "Why Dubai and Abu Dhabi continue to command investor attention",
      body: "Before comparing prices, returns or locations, it is worth starting with the question behind every investment decision: what continues to draw people, businesses and capital to the UAE?",
      author: { name: "Richard Waind", role: "CEO", photo: "richard-waind",
        quoteTitle: "The confidence behind the UAE's property market",
        quote: "The UAE has built more than a successful property market. It has created an environment where people choose to live, establish businesses and invest for the long term. That depth of commitment continues to reinforce our confidence in the country's direction and the long-term strength and fundamentals of its property markets." },
      statsTitle: "Confidence reflected in the market",
      stats: [
        { v: "+161,000", unit: "residents", t: "Added to Dubai's population between January and July 2026, supporting the long-term need for homes." },
        { pre: "AED", v: "13.8", unit: "bn in foreign investment", t: "Entered Abu Dhabi real estate during H1 2026, an increase of 309% year on year." },
        { pre: "AED", v: "23.8", unit: "bn in residential sales", t: "More than 11,000 apartment, villa and townhouse sales were completed in Dubai during August 2026." },
        { v: "+7%", unit: "average transaction price", t: "The average transaction price rose month on month to AED 2.14 million in August, as buyers continued to transact at higher price points." }
      ] },

    { id: "s1-learn", section: "s1", tpl: "learn", bg: "penthouse-terrace",
      num: "1.1", title: "What you'll learn in this handbook",
      lede: "From understanding the UAE market to choosing an investment route, comparing locations, and navigating the buying process, this handbook helps you weigh your options and know what to expect at each stage.",
      cols: [
        { n: "01", h: "Understand the market", items: [
          ["How Dubai and Abu Dhabi markets responded to uncertainty", "See how both property markets reacted as conditions changed."],
          ["Where Dubai and Abu Dhabi's property markets stand today", "Understand the current market position across both emirates."],
          ["How residents see the market ahead", "Explore what people living in the UAE expect from the property market next."] ] },
        { n: "02", h: "Understand why investors choose the UAE", items: [
          ["Why the UAE keeps attracting global property investors", "See what continues to support the UAE's investment appeal."],
          ["The demand drivers behind the UAE property market", "Explore the population, business, connectivity and capital trends shaping property demand."],
          ["How the UAE compares with global property markets", "Compare the UAE with other major international property cities."],
          ["How the UAE compares within the GCC", "Understand how the UAE investment market compares with neighbouring Gulf markets."] ] },
        { n: "03", h: "Assess an opportunity", items: [
          ["What to check before you buy", "Know the key numbers, costs, and risks to examine before making an investment decision."] ] },
        { n: "04", h: "Choose how you want to invest", items: [
          ["Which investment scenario fits your goals?", "Compare five routes based on your income priorities, how long you plan to hold and how you expect to exit."] ] },
        { n: "05", h: "Decide where to invest", items: [
          ["The communities worth considering", "Explore Dubai and Abu Dhabi communities and identify which locations may be better suited to your investment goals."] ] },
        { n: "06", h: "Understand the buying process", items: [
          ["What happens after you choose a property", "Follow the buying journey for ready and off-plan property, from reservation through to ownership."] ] },
        { n: "07", h: "Know what support is available", items: [
          ["The support you may need along the way", "See where specialist support can help before, during, and after your purchase."] ] },
        { n: "08", h: "Investing from the UK", items: [
          ["What changes when you invest from the UK", "Understand the additional financial, tax and practical considerations that come with investing in UAE property from the UK."] ] },
        { n: "09", h: "Take the next step", items: [
          ["Your next move", "Turn what you have learned into a clearer next step for your investment."] ] }
      ] },

    /* 1.2 — hub + three journeys */
    { id: "s1-2-hub", section: "s1", tpl: "hub", bg: "abudhabi-skyline", bg2: "dubai-towers",
      num: "1.2", title: "How the UAE property market responded to uncertainty",
      lede: "Dubai's August figures show a mixed market, while Abu Dhabi's equivalent response is still being established",
      body: "Dubai completed fewer residential transactions in August than in July, but average transaction values and customer enquiries increased. Performance also differed considerably by property type and purchase route. Equivalent August data is still required to determine whether Abu Dhabi responded in the same way.",
      prompt: "Choose your view" },

    { id: "s1-2-dxb-signals", section: "s1", market: "dubai", tpl: "signals", bg: "villa-arch", city: "Dubai",
      title: "Activity softened in August, but demand held up in key segments",
      lede: "Residential transaction volume declined from July, driven mainly by lower apartment activity. However, average transaction values increased, villa and townhouse sales remained broadly stable, and both buyer and tenant enquiries improved.",
      group: "August market signals",
      signals: [
        { v: "−15%", l: "residential transactions", t: "Overall residential transaction volume declined compared with July.", dir: "down" },
        { v: "+7%", l: "average transaction value", t: "The average value of completed residential transactions increased month on month.", dir: "up" },
        { v: "Broadly stable", l: "villa and townhouse activity", t: "Overall villa and townhouse transaction volume was only 1% below July.", dir: "flat" },
        { v: "+15%", l: "off-plan villa and townhouse transactions", t: "Off-plan activity for larger homes increased despite the wider decline.", dir: "up" },
        { v: "+24%", l: "tenant enquiries", t: "Rental interest strengthened considerably during August.", dir: "up" },
        { v: "+2%", l: "buyer enquiries", t: "Buyer interest also edged higher than in July.", dir: "up" }
      ],
      note: { h: "What changed?", t: "The slowdown was not spread evenly across the market. Apartment transaction volume fell by 17%, while villa and townhouse activity remained broadly stable. Within that segment, off-plan transactions rose by 15%. This points to a shift in what buyers were purchasing, rather than a broad pullback in demand." } },

    { id: "s1-2-dxb-values", section: "s1", market: "dubai", tpl: "chartcards", city: "Dubai",
      title: "Fewer transactions, but higher average values",
      axis: ["+10%", "0%", "-10%"],
      cards: [
        { v: "−10%", l: "residential sales value", t: "The total value of residential transactions fell from July.", trend: -1 },
        { v: "+7%", l: "average transaction value", t: "The average value of each completed residential transaction increased.", trend: 1, hi: true },
        { v: "+5%", l: "average secondary transaction value", t: "Average transaction values rose in the secondary market.", trend: 1 },
        { v: "+7%", l: "average off-plan transaction value", t: "Average values also increased across off-plan transactions.", trend: 1 }
      ],
      notes: [ { h: "Why the difference?", t: "Fewer transactions were completed in August, but the average value of each sale was higher. This appears to reflect a different mix of properties being sold, rather than prices rising across the market." } ] },

    { id: "s1-2-dxb-types", section: "s1", market: "dubai", tpl: "chartcards", city: "Dubai",
      title: "Villas and townhouses held up better than apartments",
      axis: ["+20%", "0%", "-20%"],
      cards: [
        { v: "−17%", l: "apartment transactions", t: "The total value of residential transactions fell from July.", trend: -1 },
        { v: "−1%", l: "villa and townhouse transactions", t: "Overall activity for larger homes remained broadly stable.", trend: 0, hi: true },
        { v: "+15%", l: "off-plan villa and townhouse transactions", t: "Growth within this segment helped offset weaker secondary activity.", trend: 1 },
        { v: "+9%", l: "off-plan villa and townhouse sales value", t: "The value of off-plan purchases in this segment also increased.", trend: 1 }
      ],
      notes: [
        { h: "What this shows", t: "Market performance was mixed in August. Apartment activity softened, while demand for off-plan villas and townhouses strengthened." },
        { t: "For investors, the performance of the relevant property type and purchase route can be more useful than the overall transaction figure alone." } ] },

    { id: "s1-2-dxb-enq", section: "s1", market: "dubai", tpl: "statgrid", city: "Dubai",
      title: "Enquiries strengthened during August",
      stats: [
        { v: "+24%", l: "tenant enquiries", t: "Tenant interest increased considerably compared with July.", photo: "villa-arch" },
        { v: "+2%", l: "buyer enquiries", t: "Buyer interest also moved slightly higher." },
        { v: "+38%", l: "apartment leasing enquiries", t: "Rental interest in apartments recorded the strongest monthly increase." },
        { v: "+22%", l: "villa and townhouse leasing enquiries", t: "Demand for larger rental homes also strengthened." } ],
      rows: [
        { h: "Why it matters", t: "Completed transactions show what buyers have already committed to, while enquiries provide an earlier indication of developing demand. Rising buyer and tenant enquiries suggest that interest remained active despite the lower number of completed sales." },
        { h: "What this means for you", cols: [
          "August was not a uniform decline across the market. Transaction activity softened, particularly for apartments, while average transaction values, off-plan villa and townhouse activity, and customer enquiries all increased.",
          "The August data shows a month-on-month change, but it is too early to say whether this was seasonal. A longer view of July-to-August performance is needed before drawing that conclusion." ] } ] },

    { id: "s1-2-auh-signals", section: "s1", market: "abudhabi", tpl: "signals", bg: "abudhabi-aerial", city: "Abu Dhabi",
      title: "Abu Dhabi's August response requires equivalent monthly evidence",
      lede: "Abu Dhabi entered 2026 with strong development-led momentum, rising residential values and substantial off-plan activity. However, equivalent August figures are needed before its response can be compared fairly with Dubai.",
      group: "August market signals", pending: true,
      signals: [
        { v: "—", l: "residential transactions", t: "Month-on-month change from July to August 2026." },
        { v: "—", l: "residential sales value", t: "Month-on-month change in the total value of residential transactions." },
        { v: "—", l: "average transaction value", t: "Change in the average value of completed residential purchases." },
        { v: "—", l: "off-plan activity", t: "Month-on-month transaction movement and share of total activity." },
        { v: "—", l: "buyer demand", t: "Change in buyer enquiries from July to August." },
        { v: "—", l: "rental demand", t: "Change in tenant enquiries or new residential lease activity." } ],
      note: { h: "What this will tell us", t: "These figures will show whether Abu Dhabi also recorded lower completed activity during August, whether its off-plan-led market remained resilient, and whether buyer and rental demand moved differently from transaction volume." } },

    { id: "s1-2-auh-types", section: "s1", market: "abudhabi", tpl: "statgrid", city: "Abu Dhabi",
      title: "Property types and purchase routes", pending: true,
      stats: [
        { v: "—", l: "apartment transactions", t: "Month-on-month change from July to August.", photo: "abudhabi-coast" },
        { v: "—", l: "villa and townhouse transactions", t: "Month-on-month change from July to August." },
        { v: "—", l: "off-plan versus secondary", t: "The performance of each purchase route during August." },
        { v: "—", l: "apartment and villa rental demand", t: "Month-on-month change in enquiries or new lease activity." } ],
      rows: [ { h: "Why it matters", t: "Abu Dhabi's market is more concentrated in new development. Understanding which property types, projects and purchase routes remained active will provide a more useful investor view than the overall market figure alone." } ] },

    { id: "s1-2-auh-h1", section: "s1", market: "abudhabi", tpl: "chartcards", bg: "abudhabi-marina", city: "Abu Dhabi", dark: true,
      title: "The market entered the year with strong growth",
      cards: [
        { v: "+178%", l: "in residential sales value", t: "Residential sales value increased substantially from H1 2025.", trend: 1 },
        { v: "AED 70.4bn", l: "residential sales value", t: "Recorded during H1 2026.", trend: 1 },
        { v: "82%", l: "of transactions were off-plan", t: "More than four in every five residential transactions were for off-plan property.", trend: 1, hi: true },
        { v: "89%", l: "of sales value came from off-plan", t: "Off-plan properties accounted for an even greater share of residential sales value.", trend: 1 } ],
      notes: [
        { h: "What this shows", t: "Abu Dhabi entered the period with strong sales growth and a market heavily driven by off-plan property. The H1 figures provide useful context, but they do not tell us how the market performed specifically during August." },
        { h: "What this means for you", t: "Abu Dhabi's underlying growth remains encouraging, but much of the market depends on new developments. When considering an off-plan opportunity, look carefully at the developer's track record, payment plan, future supply and likely demand at handover." } ] },

    { id: "s1-2-compare", section: "s1", market: "compare", tpl: "compare",
      title: "How Dubai and Abu Dhabi compare across key August indicators",
      head: ["Investor question", "Dubai", "Abu Dhabi"],
      photos: ["dubai-towers", "abudhabi-skyline"],
      rows: [
        ["August transaction movement", "−15% from July", "Equivalent August data pending"],
        ["Average transaction value", "+7% from July", "Equivalent August data pending"],
        ["Property type holding up better", "Villas and townhouses", "Equivalent August data pending"],
        ["Buyer demand", "Enquiries +2%", "Equivalent August data pending"],
        ["Rental demand", "Tenant enquiries +24%", "Equivalent August data pending"],
        ["Principal watchpoint", "Uneven performance across property types and purchase routes", "Concentration in new development"] ],
      after: { h: "What the difference means", cols: [
        "Dubai's August results show that lower completed activity did not translate into weaker demand across every part of the market. Average transaction values increased, enquiries strengthened, and off-plan villa and townhouse sales performed better than the wider market.",
        "Abu Dhabi entered the period with stronger development-led momentum, but equivalent August figures are still needed to determine how transaction activity, buyer demand and rental demand responded.",
        "Dubai currently provides more evidence from an established ready-property and rental market. Abu Dhabi offers a different growth opportunity, with greater importance placed on developer selection, project delivery and future demand." ],
        foot: "The reporting periods and methodologies currently available for Dubai and Abu Dhabi differ. Until equivalent August data is available, the figures should be used to understand the position of each market rather than treated as directly comparable measures." } },

    /* 1.3 — hub + journeys */
    { id: "s1-3-hub", section: "s1", tpl: "hub", bg: "abudhabi-skyline", bg2: "dubai-towers",
      num: "1.3", title: "Where the UAE property market stands today",
      lede: "Dubai offers established scale while Abu Dhabi enters a faster growth phase",
      body: "The UAE contains two property markets at different stages of development. Dubai remains the larger, more internationally traded market, with substantial transaction depth across ready and off-plan property. Abu Dhabi is expanding more rapidly, led by new development and rising international investment. Both markets continue to attract capital, but neither is performing uniformly. Understanding where activity is concentrated — and what is driving it — is now more important than relying on overall market growth.",
      prompt: "Select a market to explore",
      aside: { h: "Consistent information structure", t: "Each view should answer the same five questions:", items: ["How active is the market?", "What is driving activity?", "What is happening to prices?", "What is supporting demand?", "What should investors watch?"] } },

    { id: "s1-3-dxb", section: "s1", market: "dubai", tpl: "fivecols", bg: "palm-villa", city: "Dubai view",
      title: "Dubai remains active as the market resets from exceptional 2025 levels",
      source: "Latest DLD position · August 2026",
      cols: [
        { q: "How active is the market?", v: "11,087", l: "sales were completed", t: "Apartment, villa and townhouse transactions purchased increased month on month. Activity was 37% lower year on year against an exceptionally strong August 2025, but almost matched the 11,106 sales recorded in August 2023." },
        { q: "What is driving activity?", v: "71%", l: "of sales were off-plan", t: "Off-plan property accounted for 7,904 transactions, confirming that new development continues to drive most market activity." },
        { q: "What is happening to prices?", v: "+7%", l: "average transaction price", t: "The average price of properties purchased increased month on month to AED 2.14 million, although it remained approximately 10% below August 2025." },
        { q: "What is supporting demand?", v: "+24%", l: "tenant enquiries", t: "Tenant interest increased month on month and remained 9% higher year on year, supporting the depth of the rental market." },
        { q: "What should investors watch?", hl: "Property selection matters more as performance becomes less uniform", t: "Dubai continues to offer scale and liquidity, but your potential return will increasingly depend on the property's entry price, future supply, achievable rent and likely resale demand." } ] },

    { id: "s1-3-auh", section: "s1", market: "abudhabi", tpl: "fivecols", bg: "abudhabi-skyline", city: "Abu Dhabi view",
      title: "Abu Dhabi is accelerating through new development and international investment",
      source: "Latest official market position · H1 2026",
      cols: [
        { q: "How active is the market?", pre: "AED", v: "70.4bn", l: "residential sales value", t: "Residential property sales increased 178% year on year during the first half of 2026, exceeding the total recorded throughout 2025." },
        { q: "What is driving activity?", v: "82%", l: "of transactions were off-plan", t: "New development represented 89% of residential sales value, making off-plan property the principal driver of Abu Dhabi's current growth." },
        { q: "What is happening to prices?", v: "+20%", l: "apartment repeat-sale prices", t: "Annual repeat-sale prices increased by 20% for apartments and 12% for villas, showing that growth extended beyond newly launched projects." },
        { q: "What is supporting demand?", pre: "AED", v: "13.8bn", l: "foreign investment", t: "Foreign direct investment in Abu Dhabi real estate increased 309% year on year." },
        { q: "What should investors watch?", pre: "AED", v: "13.8bn", l: "of sales value came from just ten projects", t: "Growth is concentrated in a relatively small number of developments, so your choice of developer and project, the entry price and future supply around it, are critical to your investment's performance." } ] },

    { id: "s1-3-compare", section: "s1", market: "compare", tpl: "compare",
      title: "Compare both view",
      head: ["Investor question", "Dubai", "Abu Dhabi"],
      photos: ["dubai-towers", "abudhabi-skyline"],
      subhead: ["An established, high-volume market with strong international participation", "A smaller market accelerating rapidly"],
      rows: [
        ["Current position", "11,087 residential sales worth AED 23.8bn in August", "AED 70.4bn in residential sales during H1"],
        ["Latest activity", "Average transaction price rose 7% MoM but remained 10% lower YoY", "Residential sales value increased 178% YoY"],
        ["Off-plan share", "71% of August transactions", "82% of H1 transactions and 89% of sales value"],
        ["Price signal", "Average transaction price rose to AED 2.14m", "Repeat-sale prices increased 20% for apartments and 12% for villas YoY"],
        ["Demand signal", "Tenant enquiries increased 24% MoM and 9% YoY", "Foreign property investment increased 309% YoY"],
        ["What should you watch?", "Softer volumes and increasingly uneven performance", "Activity concentrated in off-plan developments and major projects"] ],
      after: { h: "Two markets at different stages of growth", sub: "What does the difference mean for you?", cols: [
        "Dubai offers greater scale and a deeper ready-property market; Abu Dhabi offers faster growth with greater concentration.",
        "In Dubai, you can draw on more evidence of achievable rents, resale demand and established community performance. Abu Dhabi presents a faster-growth opportunity, but your potential return will depend more heavily on choosing the right developer and project, successful delivery and the strength of future demand." ],
        foot: "The latest reporting periods and price methodologies differ between Dubai and Abu Dhabi. These figures indicate the direction of each market and should not be interpreted as directly equivalent measures." } },

    /* 1.4 — hub + journeys */
    { id: "s1-4-hub", section: "s1", tpl: "hub", bg: "abudhabi-skyline", bg2: "dubai-towers",
      num: "1.4", title: "How residents see the market ahead",
      lede: "The people living here are planning for the long term",
      body: "Property data tells us what people are buying today. Our Future Living Survey looks further ahead: how long residents plan to stay, how confident they feel and whether buying property is part of their future.",
      prompt: "Select a market to explore" },

    { id: "s1-4-dxb", section: "s1", market: "dubai", tpl: "survey", city: "Dubai", title: "Residents are thinking long term",
      stats: [
        { v: "69%", l: "intend to stay in Dubai for more than 10 years", t: "The longer people stay, the longer they need somewhere to live. For property investors, that helps support a deeper, more established pool of rental and buyer demand.", photo: "palm-villa" },
        { v: "70%", l: "are confident in Dubai's long-term economic growth and property prospects", t: "Property is usually a long-term decision. When residents are confident about where a city is heading, they have more reason to put down roots, rent for longer or eventually buy." },
        { v: "67%", l: "kept or strengthened their property plans despite recent regional uncertainty", t: "Markets will go through periods of uncertainty. The fact that most residents surveyed did not step back from their property plans suggests their decisions are being made with a longer horizon in mind." },
        { v: "55%", l: "of renters intend to buy within the next one to three years", t: "Renters matter to an investor twice: first as potential tenants, and later as potential buyers. A large group considering ownership can help broaden future resale demand." } ] },

    { id: "s1-4-auh", section: "s1", market: "abudhabi", tpl: "survey", city: "Abu Dhabi", title: "Residents are thinking long term",
      stats: [
        { v: "59%", l: "intend to stay in Abu Dhabi for more than 10 years", t: "People who expect to stay need homes for the long term. That gives investors a more durable source of housing demand than a population largely planning to move on.", photo: "abudhabi-coast" },
        { v: "70%", l: "are confident in Abu Dhabi's long-term economic growth and property prospects", t: "Confidence gives residents more reason to make longer-term decisions about where they live and what they own. That matters in a market attracting new residential development and investment." },
        { v: "74%", l: "kept or strengthened their property plans despite recent regional uncertainty", t: "Demand is more reassuring when it can hold up through less certain periods. Most residents surveyed did not retreat from their property plans, giving investors another measure of longer-term commitment." },
        { v: "43%", l: "of renters intend to buy within the next one to three years", t: "Today's tenants can become tomorrow's buyers. As more renters consider ownership, investors have another potential source of demand when they eventually come to sell." } ] },

    { id: "s1-4-compare", section: "s1", market: "compare", tpl: "compare", title: "Compare both",
      head: ["Investor question", "Dubai", "Abu Dhabi"], photos: ["dubai-towers", "abudhabi-skyline"],
      rows: [
        ["Plan to stay 10+ years", "69%", "59%"],
        ["Confident in long-term economic and property prospects", "70%", "70%"],
        ["Property plans maintained or strengthened despite regional uncertainty", "67%", "74%"],
        ["Renters intending to buy within 1–3 years", "55%", "43%"] ],
      after: { cols: [
        "Dubai has the stronger intention to stay and buy, while Abu Dhabi residents were more likely to maintain or strengthen their property plans through recent uncertainty.",
        "For an investor, the important point is what sits behind these numbers: people who plan to stay need homes, renters create income demand today, and some of those renters may become buyers later. Both cities therefore have resident demand supporting the market beyond today's transactions." ],
        foot: "Source: betterhomes Future Living Surveys 2026. Dubai: 1,714 completed responses. Abu Dhabi: 442 completed responses. Purchase intention is based on renters surveyed in each emirate. “Property plans maintained or strengthened” combines respondents whose plans were unchanged, who became more committed to buying or staying, or who accelerated their plans following recent regional developments. Self-selected betterhomes audiences; findings are directional and not representative of all Dubai or Abu Dhabi residents." } },

    /* ───────────────────────── 02  GLOBAL APPEAL ───────────────────────── */
    { id: "s2-open", section: "s2", tpl: "opener", bg: "villa-garden", num: "02",
      title: "Why the UAE keeps attracting global property investors",
      body: "The UAE's appeal is not built on one headline figure. Investors are looking at how much it costs to buy, what a property could earn, the costs of owning it and the wider benefits available to overseas buyers.",
      author: { name: "Harry Martin", role: "Head of Off-Plan and Capital Markets, betterhomes", photo: "harry-martin",
        quoteTitle: "The UAE's appeal to global investors isn't a trend,",
        quote: "it's far more structural. When you look at the fundamentals: a tax-efficient environment, a rapidly maturing legal framework, strong population growth, and a government that actively courts international capital, you start to understand why this market has continued to outperform. Within the GCC it stands apart on liquidity and transparency, and when you benchmark it against established global property cities, the yield premium and growth trajectory still make a compelling case." },
      statsTitle: "Three reasons investors keep looking at the UAE",
      stats: [
        { v: "6%", unit: "approaching", t: "Indicative gross rental yields in this benchmark. This shows the income a property could produce before service charges, maintenance, financing and personal tax are deducted." },
        { v: "No annual", unit: "property tax", t: "Dubai and Abu Dhabi do not apply an annual tax simply for owning a property. That can help an investor retain more of the property's income, although service charges and other ownership costs still apply." },
        { pre: "AED", v: "2", unit: "million Golden Visa threshold", t: "Qualifying property investment may provide access to a ten-year UAE Golden Visa, subject to current eligibility requirements. For some investors, the property can support both a financial objective and a longer-term plan to live in or spend more time in the UAE." } ] },

    { id: "s2-1-intro", section: "s2", tpl: "hub", bg: "balcony-marina", num: "2.1",
      title: "The demand drivers behind the UAE property market",
      lede: "What is supporting property demand beyond transactions?",
      body: "Property prices and transactions tell you what has already happened. To understand where demand may come from next, it helps to look at what creates the need for homes in the first place: population growth, employment, business expansion and the amount of new housing coming to market. The important question is not simply whether demand is growing. It is whether the number of people who need homes is growing faster than the supply available to them.",
      nochoice: true },

    { id: "s2-1-drivers", section: "s2", tpl: "tabs", bg: "villa-beach",
      tabs: [
        { n: "01", h: "More people need homes", stat: { v: "4.58", l: "million residents", t: "Dubai population at the end of 2025 · 332,000 more than the year before" },
          stats: [ { v: "4.58 million", l: "Dubai residents, end of 2025" }, { v: "+332,000", l: "increase compared with the previous year" }, { v: "4.14 million", l: "Abu Dhabi residents, 2024" }, { v: "+7.5% YoY", l: "Abu Dhabi population growth" } ],
          h2: "Population growth creates the demand", cols: [
            "Dubai added more than 300,000 residents in a single year. More residents can mean a larger pool of potential tenants and future buyers — but investors also need to consider how quickly new homes are being delivered alongside that growth.",
            "Dubai and Abu Dhabi are both expanding quickly, although the latest official figures are from different periods. Dubai's latest confirmed year-end population is for 2025; Abu Dhabi's latest official population figure is for 2024.",
            "More residents usually means more demand for homes. But for an investor there is another number that matters: how many new homes are being built for them. Dubai delivered approximately 24,300 new homes in 2025, a record level of completions and 7.6% higher YoY." ],
          foot: "This is why citywide population growth is only the starting point. The more useful comparison is at community level: how quickly demand is growing versus how many competing homes are being delivered nearby." },
        { n: "02", h: "Employment supports housing demand", stat: { v: "+2.5%", l: "UAE private-sector workforce growth", t: "Registered in early 2026, while the skilled workforce grew by a further 1.5%" },
          stats: [ { v: "+2.5%", l: "UAE private-sector workforce growth, early 2026" }, { v: "+1.5%", l: "growth in the skilled workforce" }, { v: "+0.4%", l: "growth in the number of private-sector companies" } ],
          h2: "Jobs give people a reason — and the means — to live here", cols: [
            "When companies expand they hire people. Those employees need somewhere to live, and some will bring families with them. That is one of the ways business growth can turn into housing demand.",
            "Population growth tells you that more people are here. Employment helps explain why they are here, and whether there is an economic base capable of supporting housing costs.",
            "These employment figures are UAE-wide rather than Dubai-specific, so they should be read as a broader economic demand signal rather than a direct measure of Dubai housing demand." ],
          foot: "For a property investor, national or citywide employment growth is only part of the picture. Where people work, and how easily they can get there, influences where they choose to live." },
        { n: "03", h: "Employment centres remain heavily occupied", stat: { v: "~94% · ~96%", l: "average office occupancy, Dubai · Abu Dhabi", t: "Q2 2026 · CBRE" },
          stats: [ { v: "~94%", l: "average office occupancy in Dubai, Q2 2026" }, { v: "~96%", l: "average office occupancy in Abu Dhabi, Q2 2026" } ],
          h2: "Business activity helps show where demand may concentrate", cols: [
            "Office occupancy is not the same as residential occupancy, but it provides useful context about the strength of major employment centres. CBRE describes both markets as operating with tight office supply, with demand concentrated around major employment centres.",
            "For an investor, the important point is not simply that offices are full. It is that concentrations of jobs can influence residential demand around them. A community close to a growing employment hub may attract residents who value a shorter commute or easier access to work.",
            "But proximity alone is not enough. The number and type of residential properties being built nearby still matters. A location can benefit from strong employment demand and still face pressure if too many similar homes are competing for the same tenants." ] },
        { n: "04", h: "Business expansion is creating new centres of demand", stat: { v: "10,000+", l: "active companies", t: "Registered in DIFC by the end of June 2026 · 1,933 new firms, up 32%" },
          stats: [ { v: "10,000+", l: "active registered companies in DIFC" }, { v: "+32%", l: "growth in new firms registered" } ],
          h2: "Growing hubs create new pools of tenants", cols: [
            "Dubai's employment base is continuing to broaden. DIFC reported more than 10,000 active registered companies, while its AI, fintech and innovation business base continued to expand. CBRE describes demand as particularly concentrated around major employment centres including DIFC in Dubai and ADGM in Abu Dhabi.",
            "Business growth does not automatically translate into property demand everywhere. But when employment expands within specific commercial hubs, nearby residential communities can benefit from a larger potential tenant and buyer pool.",
            "Where jobs are located can influence where employees choose to live — making access to employment centres an important part of community-level demand." ] } ] },

    { id: "s2-1-summary", section: "s2", tpl: "hub", bg: "villa-lawn", num: "",
      title: "Demand is giving the market room to grow", nochoice: true,
      cols: [
        "Population growth, expanding private-sector employment and continued business activity are all adding to the number of people who may need homes across the UAE.",
        "Dubai added 332,000 residents in 2025, while the UAE's private-sector workforce continued to grow in early 2026. Business registrations in DIFC also expanded, broadening the employment base.",
        "At the same time, housing supply is increasing. Dubai delivered a record 24,300 new homes in 2025, so the demand-versus-supply picture at community level matters more than any single citywide figure.",
        "Together, these factors point to a growing demand base, but the strength of that demand will vary by location, property type and price point." ] },

    /* 2.2 GCC */
    { id: "s2-2-hub", section: "s2", tpl: "hub", bg: "dubai-creek", num: "2.2",
      title: "How the UAE compares within the GCC",
      body: "With GCC markets all opening up to international property investment, investors can now compare the UAE with Riyadh, Doha and Muscat on scale, maturity and risk. Dubai and Abu Dhabi offer the deepest, most internationally traded markets in the region; the others are earlier in their investment journey.",
      prompt: "Select a market to explore" },

    { id: "s2-2-dxb", section: "s2", market: "dubai", tpl: "fivecols", bg: "burj-arab-villa", city: "Dubai", title: "Established scale",
      source: "Dubai at a glance",
      intro: "The region's most established international property market. Dubai combines broad and liquid rental and resale markets with a large range of ready and off-plan property. For an investor, that scale provides more evidence to work with. You can compare prices, achievable rents and competing properties before deciding where, and at what price, to buy.",
      cols: [
        { q: "Representative one-bedroom price", pre: "~AED", v: "1.2M", l: "" },
        { q: "Indicative gross rental yield", v: "~7%", l: "" },
        { q: "International ownership", hl: "Broad freehold access in designated areas" },
        { q: "Property choice", hl: "Wide choice across ready and off-plan" },
        { q: "Resale market", hl: "The GCC's deepest secondary market" } ],
      trade: { h: "The trade-off", t: "More choice also means more competition between properties. That makes selection important: the price you pay, future supply nearby, achievable rent and likely resale demand all influence how a Dubai property performs." } },

    { id: "s2-2-dxb-cities", section: "s2", market: "dubai", tpl: "cities", city: "Dubai", title: "How Dubai compares across the GCC",
      cities: [
        { name: "Riyadh", tag: "Transformation market", photo: "riyadh", t: "Economic expansion and major development are creating new residential opportunities as international property purchase rules open up." },
        { name: "Doha", tag: "Established smaller market", photo: "doha", t: "International buyers can access property in designated locations, but property choice and the resale market are narrower than in Dubai." },
        { name: "Muscat", tag: "Emerging lifestyle market", photo: "muscat", t: "Tourism-led integrated developments offer a lower entry point with a smaller and less liquid international market." } ] },

    { id: "s2-2-auh", section: "s2", market: "abudhabi", tpl: "fivecols", bg: "abudhabi-balcony", city: "Abu Dhabi", title: "Development-led growth",
      source: "Abu Dhabi at a glance",
      intro: "A smaller market with a growing international investment base. Abu Dhabi is leading the property market expansion through new development, and off-plan property represents the majority of transactions. For an investor, this creates a different proposition: faster growth and a more concentrated set of opportunities, but with more depending on the developer and project.",
      cols: [
        { q: "Representative one-bedroom price", pre: "~AED", v: "1.4M", l: "" },
        { q: "Indicative gross rental yield", v: "~6.5%", l: "" },
        { q: "International ownership", hl: "Freehold in designated investment zones" },
        { q: "Property choice", hl: "A new and more concentrated market" },
        { q: "Resale market", hl: "Growing, but more limited than Dubai" } ],
      trade: { h: "The trade-off", t: "A smaller, newer market can mean less evidence of achievable rents and resale demand. That places more weight on developer selection, project delivery and future supply." } },

    { id: "s2-2-auh-cities", section: "s2", market: "abudhabi", tpl: "cities", city: "Abu Dhabi", title: "How Abu Dhabi compares across the GCC",
      cities: [
        { name: "Riyadh", tag: "Transformation market", photo: "riyadh", t: "Economic expansion and major development are creating new residential opportunities as international property purchase rules open up." },
        { name: "Doha", tag: "Established smaller market", photo: "doha", t: "International buyers can access property in designated locations, but property choice and the resale market are narrower." },
        { name: "Muscat", tag: "Emerging lifestyle market", photo: "muscat", t: "Tourism-led integrated developments offer a lower entry point with a smaller and less liquid international market." } ] },

    { id: "s2-2-compare", section: "s2", market: "compare", tpl: "compare", title: "Compare both",
      intro: "Two UAE markets. Two different investment propositions.",
      head: ["Decision factor", "Dubai", "Abu Dhabi", "Riyadh", "Doha", "Muscat"],
      rows: [
        ["Market position", "Established international market", "Development-led growth market", "Transformation market", "Established smaller market", "Emerging lifestyle market"],
        ["Representative 1BR price", "~AED 1.2M", "~AED 1.4M", "~AED 0.7–1.0M", "~AED 1.0M", "~AED 0.6M"],
        ["Indicative gross yield", "~7%", "~6.5%", "~6%", "~6%", "~5–6%"],
        ["International ownership", "Broad freehold access", "Freehold in designated zones", "Opening to international buyers", "Designated locations", "Integrated tourism complexes"],
        ["Property choice", "Wide — ready and off-plan", "Growing, off-plan led", "Expanding", "Narrower", "Limited"],
        ["Resale market", "Deepest in the GCC", "Growing", "Early stage", "Smaller", "Smaller, less liquid"],
        ["Residency connection", "Golden Visa eligible", "Golden Visa eligible", "Premium residency routes", "Residency by investment", "Investor residency"] ],
      after: { h: "Why these differences matter", cols: [
        "More evidence to compare: Dubai's larger, more established market gives investors more comparable properties and more transaction evidence before they buy.",
        "More exposure to newer development: Abu Dhabi and Riyadh offer faster-moving markets with more depending on the developer, the project and future supply.",
        "More concentrated lifestyle markets: Doha and Muscat offer narrower ranges of international locations, which can mean less competition but also less liquidity." ] } },

    /* 2.3 Global */
    { id: "s2-3-hub", section: "s2", tpl: "hub", bg: "dubai-skyline-blue", num: "2.3",
      title: "How the UAE compares with global property markets",
      body: "Compared with established property markets around the world, the UAE combines a lower representative purchase price with indicative gross rental yields, approaching 6%, and no annual property tax. For an investor, the important point is how these factors work together: the price needed to enter the market, the income a property could produce and the costs that reduce it. Below, Dubai and Abu Dhabi are compared with the three major global property cities.",
      nochoice: true },

    { id: "s2-3-global", section: "s2", tpl: "global", bg: "dubai-skyline-wide", title: "Dubai, Abu Dhabi and global property cities",
      cities: [
        { name: "Dubai", price: "Dhs 1.02 million", yield: "5.5–6.0%", net: "4.0–4.5%", t: "The gap between gross and net yield reflects the cost of service charges, letting and management." },
        { name: "Abu Dhabi", price: "Dhs 1.0 million", yield: "5.8%", net: "4.0–4.5%", t: "The net yield also allows for typical property management and letting costs." },
        { name: "London", price: "Dhs 1.9 million", yield: "4–5%", net: "~2.5%", t: "Stamp duty and the annual tax on rental income reduce the net return for an overseas buyer; a one-bedroom purchase is typically more than double the cost of entering Dubai or Abu Dhabi." } ],
      selector: ["London", "New York", "Singapore"] },

    /* ───────────────────────── 03  WHAT TO CHECK ───────────────────────── */
    { id: "s3-open", section: "s3", tpl: "opener", bg: "penthouse-burj", num: "03", simple: true,
      title: "What to check before you buy", sub: "3.1 Verify your property",
      lede: "A good property is not automatically a good investment",
      body: "Before committing, look beyond the asking price, projected return or launch offer. First, verify what you are buying. Then understand how much money the purchase will really require, what it may cost to own and whether the property supports the outcome you are buying for. Some checks apply to every purchase. Others become more important depending on your property type and investment goals.",
      chooser: { label: "Property type", key: "ptype", options: [["offplan", "Off-plan"], ["ready", "Ready"]] } },

    { id: "s3-1-verify", section: "s3", tpl: "checklist", bg: "burj-arab-aerial", num: "3.1", title: "Verify your property",
      variants: {
        ready: [
          { n: "01", h: "Verify the property details", t: "Start by making sure the property, project and listing information can be independently verified.", items: ["Property or project name", "Unit details", "Advertised price", "Listing or advertising permit, where applicable", "Who is authorised to receive payments"] },
          { n: "02", h: "Verify who you are dealing with", t: "Make sure the people and companies involved in the transaction can be independently verified.", items: ["Broker name and registration", "Brokerage company", "Developer, where applicable", "Project registration, where applicable", "Who is authorised to receive payments"] },
          { n: "03", h: "Check that the paperwork matches the property", t: "Small differences matter when you are buying a specific unit, so make sure the documents match what you were shown and agreed to.", items: ["Unit number", "Building or project", "Floor", "Internal area", "Balcony or terrace", "Parking allocation", "Purchase price", "Payment schedule", "Completion or handover date, where applicable", "Included fixtures and furnishings, where relevant"] },
          { n: "04", h: "Verify the ownership details", t: "Confirm the property's ownership position before progressing with the transfer.", items: ["Registered owner", "Property details", "Existing mortgage, where applicable", "Whether the property is vacant or tenanted", "Documentation required before transfer"] },
          { n: "05", h: "Review the tenancy details", t: "If the property is rented, remember that you are acquiring an existing tenancy as well as the property.", items: ["Current tenancy contract", "Contract dates", "Payment schedule", "Security deposit details", "Renewal history, where available", "Relevant notices already issued"], q: "Am I comfortable with the tenancy I will be taking over?" },
          { n: "06", h: "Assess the property condition", t: "The purchase price does not always reflect the additional capital the property may require.", items: ["General property condition", "Age of major fittings and equipment", "Building condition and common areas", "Inspection or snagging report, where appropriate", "Property management arrangement, if applicable"] } ],
        offplan: [
          { n: "01", h: "Verify the property details", t: "Start by making sure the property, project and listing information can be independently verified.", items: ["Project name and developer", "Unit details", "Advertised price", "Listing or advertising permit", "Who is authorised to receive payments"] },
          { n: "02", h: "Verify who you are dealing with", t: "Make sure the people and companies involved in the transaction can be independently verified.", items: ["Broker name and registration", "Brokerage company", "Developer", "Project registration", "Escrow account, where applicable"] },
          { n: "03", h: "Check that the paperwork matches the property", t: "Make sure the documents match what you were shown and agreed to.", items: ["Unit number and floor", "Internal area and layout", "Purchase price", "Payment schedule", "Completion or handover date", "Included fixtures and finishes"] },
          { n: "04", h: "Verify the project details", t: "Confirm the project is properly registered and that the plot and permits are in place to support delivery.", items: ["Developer", "Project registration", "Expected handover date", "Land ownership and permits", "Payment arrangements", "Construction progress"], q: "Does the information provided match what is on the register?" },
          { n: "05", h: "Assess the developer's track record", t: "Beyond the project itself, consider the developer's history on comparable projects.", items: ["Previously completed projects", "Delivery history", "Quality of completed projects", "Reputation for after-sales and management", "Performance of comparable completed projects"], q: "Has this developer delivered on time before?" },
          { n: "06", h: "Review the payment plan", t: "Make sure you understand what is payable, when it falls due, and what happens if the schedule changes.", items: ["Deposit", "Construction instalments", "Handover payment", "Post-handover payments, if applicable", "Any fees payable at each stage"], q: "Can I meet every payment, on time, in the agreed currency?" } ] } },

    { id: "s3-2-cost", section: "s3", tpl: "checklist", bg: "burj-arab-sunset", num: "3.2", title: "Know the full cost before you buy",
      lede: "The asking price is only the starting point.",
      body: "Before you buy, understand how much cash you will need, when payments are due, what the property may cost to own each year, and how realistic the expected rental income is.",
      steps: [
        { n: "01", h: "Know your full cash requirement", t: "The deposit is only part of the cash you may need. Work out the full amount required to complete the purchase, and when each payment is likely to fall due.", items: ["Purchase price", "Registration and transaction costs", "Brokerage fees, where applicable", "Mortgage-related costs", "Valuation costs, where applicable", "Currency conversion and transfer costs", "Conveyancing or professional fees, where used", "Initial repairs, furnishing or fit-out, where required"], sub: "For off-plan property also include: construction instalments, handover payment, initial costs due at handover and any remaining balance." },
        { n: "02", h: "Understand the ongoing cost of ownership", t: "Two properties with a similar purchase price can have very different annual costs.", items: ["Service charges", "Property management", "Insurance, where applicable", "Building or community fees", "Mortgage repayments and financing costs", "Furnishing or replacement costs, where relevant", "Vacancy allowance, if rented", "Other recurring ownership costs"], sub: "Where historical information is available, look at several years' numbers rather than relying on a single estimate." },
        { n: "03", h: "Test the expected rent", t: "A headline yield is only useful if the rent behind it is realistic. Look at comparable properties rather than relying on the highest advertised asking rent.", items: ["The same building or community, where possible", "The same property type and bedroom count", "A similar condition and level of furnishing", "View or position, where relevant"], sub: "Then move beyond gross rent and look at what may remain after the ongoing costs of owning and letting the property." } ] },

    { id: "s3-3-fit", section: "s3", tpl: "checklist", bg: "dubai-canal", num: "3.3", title: "Check whether the property fits your investment goal",
      lede: "Look at the property through your investor profile",
      body: "After checking the property and the numbers, your next question should be whether this particular opportunity fits what you are trying to achieve. The priorities below change according to your investor profile.",
      chooser: { label: "Investor profile", key: "profile", options: [["income", "Income Builder"], ["growth", "Growth Investor"]] },
      variants: {
        income: [
          { n: "01", h: "Is the expected rent realistic?", t: "Look at recent rents achieved for comparable properties rather than relying only on advertised rents.", items: ["The same building or community, where possible", "The same property type and bedroom count", "A similar condition and level of furnishing", "Floor, view or position, where relevant", "Current availability"] },
          { n: "02", h: "What will you earn after costs?", t: "Gross yield only tells part of the story. Allow for the ongoing costs of owning and letting the property.", items: ["Service charges", "Property management", "Maintenance", "Financing costs, where applicable", "Other recurring expenses"] },
          { n: "03", h: "How strong is tenant demand?", t: "Reliable income depends on being able to attract and replace tenants without long gaps.", items: ["Who typically rents in the area", "How many similar properties are available", "How long comparable homes take to let", "Whether demand changes at different times of year", "Which features tenants are willing to pay more for"] },
          { n: "04", h: "How well does the income hold up?", t: "Test the investment using slightly less favourable assumptions.", items: ["Rent 5–10% lower", "A longer vacancy period", "Higher maintenance or service charges", "Higher financing costs", "Ready exit if plans change"], focus: ["Achievable rent", "Net income", "Tenant demand", "Vacancy risk"] } ],
        growth: [
          { n: "01", h: "Are you buying at a sensible price?", t: "Compare the property with other options before deciding what represents good value.", items: ["Recent sale prices for comparable properties", "Similar units in the same development or community", "Comparable properties in competing developments", "Price per square foot, where useful", "Ready and off-plan alternatives"] },
          { n: "02", h: "What could support future demand?", t: "Look beyond the property itself and consider what could make the wider area more attractive over time.", items: ["New infrastructure", "Transport and connectivity", "Access to employment centres", "Population growth", "Schools and amenities", "New commercial districts", "Development of the wider community"] },
          { n: "03", h: "How much competing supply is coming?", t: "New development can strengthen an area, but it can also give future buyers more choice.", items: ["New projects nearby", "Similar property types and sizes", "Expected handover dates", "Higher incentive buyers", "Scale of the development pipeline"] },
          { n: "04", h: "Who might buy it from you later?", t: "Think about the future buyer before you buy.", items: ["End users", "Families", "Investors", "Residents considering ownership", "Record demand"], focus: ["Entry price", "Future demand", "Future supply", "Resale demand"] } ] } },


    /* ───────────────────────── 04  INVESTMENT SCENARIOS (content pending) ───────────────────────── */
    { id: "s4-open", section: "s4", tpl: "opener", bg: "villa-palms", num: "04", simple: true,
      title: "Which investment scenario fits your goals?", sub: "4.1 Five investor routes compared",
      lede: "Content for this section is being finalised",
      body: "This section will compare five routes based on your income priorities, how long you plan to hold and how you expect to exit. Add the slides to slides.js under section s4 when the copy is ready." },

    /* ───────────────────────── 05  COMMUNITIES ───────────────────────── */
    { id: "s5-open", section: "s5", tpl: "map", bg: "dubai-aerial-sun", bgs: { dubai: "dubai-aerial-sun", abudhabi: "abudhabi-aerial" }, num: "05",
      title: "The communities worth considering", sub: "Recommended communities",
      marketLabels: { dubai: "Dubai", abudhabi: "Abu Dhabi" },
      filters: ["Featured for you", "All communities"],
      pins: { dubai: [["Dubai Marina", 0.36, 0.72], ["Palm Jumeirah", 0.29, 0.56], ["Business Bay", 0.58, 0.47], ["Downtown", 0.64, 0.42], ["Dubai Hills", 0.52, 0.6], ["Dubai Creek", 0.78, 0.38], ["Arabian Ranches", 0.46, 0.84], ["JVC", 0.42, 0.69]],
             abudhabi: [["Al Reem Island", 0.52, 0.42], ["Saadiyat Island", 0.6, 0.28], ["Yas Island", 0.75, 0.31], ["Al Raha Beach", 0.68, 0.5], ["Al Maryah Island", 0.5, 0.47], ["Masdar City", 0.74, 0.62]] },
      card: { status: "Ready, mature", type: "1-3 bed apts, penthouses", price: "1,800–2,400", priceLabel: "AED / sqft", yield: "5.9%", yieldLabel: "average gross rental yield", entry: "1.5M", entryLabel: "entry point · AED", range: "1.5M–5.5M", rangeLabel: "price range · AED",
        notes: [["Connectivity & landmarks", "Waterfront, marina & tram, JBR beach, Marina Walk, near Media/Internet City."], ["Key strengths", "Deepest liquidity & tenant model, established rental & resale."], ["Main buyer & rental demand", "Largest tenant pool, expat professionals, strong holiday/short-let."], ["Costs, limitations & risks", "High service charges, slower price growth, oversupply in older towers."]] } },

    { id: "s5-list", section: "s5", tpl: "communities", title: "Dubai communities", num: "5.1",
      lists: {
        dubai: ["Marina", "Emaar Beachfront", "Palm Jumeirah", "Jumeirah Lake Towers (JLT)", "JBR (Jumeirah Beach Residence)", "Tecom / Greens", "Mira / Mira Oasis / Serena", "Damac Hills", "TAG (The Villa area group)", "Dubai Hills Estate", "The Villa / Falcon City / Villanova / The Valley", "The Sustainable City", "Arabian Ranches 1 & 2 / Polo Homes", "Arabian Ranches 3", "Victory Heights & JGE", "DIP / Green Community", "Emirates Living (Meadows / Springs / Lakes)", "JVT / Jumeirah Park / Jumeirah Islands", "Jumeirah Village Circle (JVC)", "Dubai South / Emaar South / Expo City", "Al Furjan / Jebel Ali", "Downtown / Old Town", "Business Bay / SZR / Satwa", "Meydan / Dubai Creek / Festival City / Culture Village / Sobha Hartland", "Jumeirah / Al Barsha / Jumeirah Bay / La Mer / City Walk"],
        abudhabi: ["Al Ghadeer", "Al Reem Island", "Masdar City", "Al Raha Beach", "Yas Island", "Al Maryah Island", "Saadiyat Island"] } },

    /* ───────────────────────── 06  AFTER YOU CHOOSE ───────────────────────── */
    { id: "s6-open", section: "s6", tpl: "split", num: "06", title: "What happens after you choose a property",
      left:  { key: "offplan", h: "Off-plan property", t: "A property you buy before construction is complete.", photo: "dubai-coast-sun" },
      right: { key: "ready",   h: "Ready property",    t: "A completed property you can buy and take ownership of now.", photo: "lounge-burj" },
      chooserKey: "ptype" },

    { id: "s6-1-ready", section: "s6", tpl: "process", bg: "lounge-burj", num: "6.1", title: "Buying a ready property in Dubai",
      body: "Once you are happy with the property and ready to proceed, the purchase moves through four main stages. For a straightforward purchase, allow around 2–4 weeks from an accepted offer to ownership. A mortgage, an existing mortgage on the property or missing paperwork can make the process longer.",
      steps: [
        { n: "01", h: "Agree the purchase", time: "1–3 days", t: "You make your offer and agree the price, completion date and main terms with the seller. The agreement is then put in writing. In Dubai, this agreement is known as Form F, the contract that records the agreed sale between you and the seller.",
          cols: [ { h: "What to have in place:", items: ["Passport or Emirates ID", "Agreed purchase price", "Preferred completion timeframe", "Mortgage pre-approval, if you are borrowing"] }, { h: "If you need a mortgage:", items: ["Have your mortgage pre-approval before you commit. Your bank will still need to value the property and give its final approval before transfer."] } ],
          end: "At the end of this step: the deal is agreed and the sale contract is signed." },
        { n: "02", h: "Get ready for transfer", time: "around 1–3 weeks", t: "This is where most of the administration happens: the property needs to be cleared for sale, your money needs to be ready, and if you are borrowing, the bank needs to complete its work.",
          cols: [ { h: "What to have in place:", items: ["Signed Form F", "Passport or Emirates ID", "Remaining purchase funds", "Money for purchase and registration costs", "Mortgage documents, if applicable", "Power of attorney, if someone is signing for you"] }, { h: "During this stage:", items: ["The seller obtains the No Objection Certificate (NOC)", "Outstanding amounts that could prevent the transfer are dealt with", "Your bank values the property if you are using a mortgage", "Final mortgage approval and bank documents are completed", "If the seller has a mortgage, its settlement and release are arranged", "The transfer is booked once the property, paperwork and funds are ready"] }, { h: "Buying from abroad?", items: ["Confirm this at the start. Depending on how the transaction is completed, you may be able to use the available remote process or appoint someone under a valid power of attorney."] } ],
          end: "At the end of this step: the property, paperwork, financing and money are ready for completion." },
        { n: "03", h: "Become the owner", time: "transfer day", t: "This is completion. The remaining purchase price and applicable fees are settled and the sale is formally registered. In Dubai, this is handled through a DLD registration, usually taking around 30 minutes once everything is ready.",
          cols: [ { h: "Have ready:", items: ["Passport or Emirates ID", "Developer's NOC", "Remaining purchase funds", "Money for DLD and applicable registration fees", "Bank documents, if you have a mortgage", "Valid power of attorney, if someone is acting for you"] }, { h: "What happens:", items: ["Final documents are checked", "Purchase funds and applicable fees are settled", "The sale is registered", "Ownership transfers to you", "Your title deed is issued"] }, { h: "If you have a mortgage:", items: ["Your bank forms part of the completion process, so its documents and funds must be ready before the transfer can be completed."] } ],
          end: "At the end of this step: you own the property." },
        { n: "04", h: "Get the property earning", time: "after transfer", t: "Can begin once ownership transfers. If you bought for rental income, the final step is getting the property ready for a tenant.",
          cols: [ { h: "If the property is vacant, have ready:", items: ["Any maintenance or furnishing budget", "Target asking rent", "Keys and access", "Bank details for rental payments", "Decide on whether you will manage it yourself or use property management"] }, { h: "If the property is already rented, have ready:", items: ["Existing tenancy agreement", "Current rent and payment schedule", "Security deposit details", "Tenancy expiry date", "Existing property management arrangements, if any"] }, { h: "What happens next:", items: ["A vacant property is prepared, priced and marketed", "A new tenancy is registered through Ejari, Dubai's tenancy registration system", "Property management can handle rent collection, maintenance and renewals if required"] } ],
          end: "At the end of this step: the property becomes an income-producing property." } ] },

    /* ───────────────────────── 07–09  (content pending) ───────────────────────── */
    { id: "s7-open", section: "s7", tpl: "opener", bg: "penthouse-terrace", num: "07", simple: true,
      title: "The support you may need along the way", sub: "7.1 Before, during and after your purchase",
      lede: "Content for this section is being finalised",
      body: "This section will show where specialist support can help before, during and after your purchase." },
    { id: "s8-open", section: "s8", tpl: "opener", bg: "dubai-skyline-wide", num: "08", simple: true,
      title: "What changes when you invest from the UK", sub: "8.1 Financial, tax and practical considerations",
      lede: "Content for this section is being finalised",
      body: "This section will cover the additional financial, tax and practical considerations that come with investing in UAE property from the UK." },
    { id: "s9-open", section: "s9", tpl: "opener", bg: "dubai-coast-sun", num: "09", simple: true,
      title: "Your next move", sub: "9.1 Turn what you have learned into a next step",
      lede: "Content for this section is being finalised",
      body: "This closing section will turn what you have learned into a clearer next step for your investment, with a call to speak to one of our experts." }
  ]
};
